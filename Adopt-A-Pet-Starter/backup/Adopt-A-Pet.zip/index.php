<?php
// Function to format age from months to years and months
function formatAge($ageMonths) {
    $years = floor($ageMonths / 12);
    $months = $ageMonths % 12;

    if ($years > 0 && $months > 0) {
        return "$years year" . ($years > 1 ? "s" : "") . ", $months month" . ($months > 1 ? "s" : "") . " old";
    } elseif ($years > 0) {
        return "$years year" . ($years > 1 ? "s" : "") . " old";
    } else {
        return "$months month" . ($months > 1 ? "s" : "") . " old";
    }
}

// Read and decode the JSON file
$jsonFile = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/data/pets.json');
$petsData = json_decode($jsonFile, true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adoption Center</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/styles.css">

</head>
<body>
    <h1>Available Pets for Adoption</h1>

    <div class="pets-grid">
        <?php foreach ($petsData as $pet): ?>
            <div class="pet-card">
                <img src="<?php echo htmlspecialchars($pet['imageUrl']); ?>" alt="<?php echo htmlspecialchars($pet['name']); ?>">
                <div class="pet-info">
                    <h2><?php echo htmlspecialchars($pet['name']); ?></h2>
                    <div class="pet-details">
                        <p><strong>Breed:</strong> <?php echo htmlspecialchars($pet['breed']); ?></p>
                        <p><strong>Age:</strong> <?php echo htmlspecialchars(formatAge($pet['ageMonths'])); ?></p>
                        <p><strong>Gender:</strong> <?php echo htmlspecialchars($pet['gender']); ?></p>
                        <p class="price">Adoption Fee: $<?php echo number_format($pet['price'], 2); ?></p>
                        <span class="house-trained <?php echo $pet['houseTrained'] ? 'trained-yes' : 'trained-no'; ?>">
                            <?php echo $pet['houseTrained'] ? 'House Trained' : 'Not House Trained'; ?>
                        </span>
                        <p><?php echo htmlspecialchars($pet['description']); ?></p>
                    </div>
                    <a href="/apply.php?id=<?php echo $pet['id']; ?>" class="apply-btn">Apply to Adopt</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>