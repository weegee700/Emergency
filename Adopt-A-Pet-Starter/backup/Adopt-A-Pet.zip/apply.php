<?php
// Read and decode the JSON file
$jsonFile = file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/data/pets.json');
$petsData = json_decode($jsonFile, true);

// Generate unique request ID (timestamp + random number)
$requestId = time() . rand(1000, 9999);
	
foreach($petsData as $pet	)	{
	if($pet['id'] == $_GET['id'])	{
		$pet = $pet;
		break;
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Adoption Request Form</title>
</head>
<body>
		<h2>Adoption Request Form</h2>
			<!-- Update the form tag to include method and action -->
			<form method="POST" action="/applyHandler.php">
				<!-- Pet Information Section -->
				<fieldset>
						<legend>Pet Information</legend>
						<input type="hidden" id="petId" name="petId" value="<?php echo $_GET['id'];?>">
						<p>
								<label for="petName">Pet Name:</label>
								<span id="petName"><?php echo $pet['name'];?></span>
						</p>
					<p>
							<label for="petName">Pet Type:</label>
							<span id="petName"><?php echo $pet['type'];?></span>
					</p>
				</fieldset>

				<!-- Applicant Information Section -->
				<fieldset>
						<legend>Applicant Information</legend>
						<input type="hidden" id="requestId" name="requestId" value="<?php echo $requestId;?>">

						<p>
								<label for="applicantName">Applicant Name:</label>
								<input type="text" id="applicantName" name="applicantName" placeholder="Enter your full name" value="Jane Smith" required>
						</p>

						<p>
								<label for="email">Email:</label>
								<input type="email" id="email" name="email" placeholder="Enter your email" value="jane.smith@example.com" required>
						</p>

						<p>
								<label for="phoneNumber">Phone Number:</label>
								<input type="text" id="phoneNumber" name="phoneNumber" placeholder="Enter your phone number" value="+1-987-654-3210" required>
						</p>

						<p>
								<label for="address">Address:</label>
								<input type="text" id="address" name="address" placeholder="Enter your address" value="5678 Oak Avenue, Metropolis, NY, 10001" required>
						</p>
				</fieldset>

				<!-- Household Information Section -->
				<fieldset>
						<legend>Household Information</legend>
						<p>
								<label>Experience with Pets:</label><br>
								<input type="radio" id="experienceYes" name="experienceWithPets" value="true" checked>
								<label for="experienceYes">Yes</label>
								<input type="radio" id="experienceNo" name="experienceWithPets" value="false">
								<label for="experienceNo">No</label>
						</p>

						<p>
								<label for="homeType">Home Type:</label>
								<select id="homeType" name="homeType">
										<option value="Apartment">Apartment</option>
										<option value="House" selected>House</option>
										<option value="House+">House+Yard</option>
										<option value="Condo">Condo</option>
										<option value="Condo+">Condo+Yard</option>
								</select>
						</p>

						<p>
								<label for="homeSize">Home Size:</label>
								<select id="homeSize" name="homeSize">
										<option value="Small">Small</option>
										<option value="Med" selected>Med</option>
										<option value="Large">Large</option>
								</select>
						</p>

						<p>
								<label for="peopleInHome">People in Home:</label>
								<select id="peopleInHome" name="peopleInHome">
										<option value="1">1</option>
										<option value="2" selected>2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
								</select>
						</p>
				</fieldset>

				<p>
						<button type="submit">Submit Request</button>
				</p>
		</form>
</body>
</html>
