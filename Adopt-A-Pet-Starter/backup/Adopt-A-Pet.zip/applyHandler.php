<?php
// Ensure this is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
		http_response_code(405);
		die('Method not allowed');
}
// Get and validate the form data
$requestData = [
		'requestId' => filter_input(INPUT_POST, 'requestId', FILTER_SANITIZE_NUMBER_INT),
		'petId' => filter_input(INPUT_POST, 'petId', FILTER_SANITIZE_NUMBER_INT),
		'applicantName' => htmlspecialchars($_POST['applicantName'] ?? '', ENT_QUOTES, 'UTF-8'),
		'email' => filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL),
		'phoneNumber' => htmlspecialchars($_POST['phoneNumber'] ?? '', ENT_QUOTES, 'UTF-8'),
		'address' => htmlspecialchars($_POST['address'] ?? '', ENT_QUOTES, 'UTF-8'),
		'experienceWithPets' => htmlspecialchars($_POST['experienceWithPets'] ?? '', ENT_QUOTES, 'UTF-8'),
		'homeType' => htmlspecialchars($_POST['homeType'] ?? '', ENT_QUOTES, 'UTF-8'),
		'homeSize' => htmlspecialchars($_POST['homeSize'] ?? '', ENT_QUOTES, 'UTF-8'),
		'peopleInHome' => filter_input(INPUT_POST, 'peopleInHome', FILTER_SANITIZE_NUMBER_INT),
		'requestDate' => date('Y-m-d H:i:s')
];

// Validate required fields
if (empty($requestData['applicantName']) || empty($requestData['email']) || empty($requestData['petId'])) {
		http_response_code(400);
		die('Missing required fields');
}

// Load existing requests or create new array
$requestsFile = $_SERVER['DOCUMENT_ROOT'] . '/data/adoptionRequests.json';
$existingRequests = [];

if (file_exists($requestsFile)) {
		$existingRequests = json_decode(file_get_contents($requestsFile), true) ?? [];
}

// Add new request
$existingRequests[] = $requestData;

// Save updated requests
if (file_put_contents($requestsFile, json_encode($existingRequests, JSON_PRETTY_PRINT))) {
		http_response_code(200);
		echo json_encode(['status' => 'success', 'message' => 'Application submitted successfully']);
} else {
		http_response_code(500);
		echo json_encode(['status' => 'error', 'message' => 'Failed to save application']);
}
?>